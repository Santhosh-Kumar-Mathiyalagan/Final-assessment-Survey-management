package net.codejava;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class survey {
    private String name;
    private String type;
    private Date startdate;
    private Date enddate;

    protected survey() {
    }

    protected survey(String name,String type,Date startdate,Date enddate) {
        super();
        this.name = name;
        this.type = type;
        this.startdate = startdate;
        this.enddate = enddate;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return Type;
    }

    public String settype(String Type) {
        this.type = type;
    }

    public Date getStartdate(Date startdate) {
        return startdate;
    }

    public Date setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Date getEnddate(Date enddate) {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }
}