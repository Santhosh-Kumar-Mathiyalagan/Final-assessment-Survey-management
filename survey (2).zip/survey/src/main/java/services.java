
package net.codejava;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional
public class services {
    @Autowired
    private repository repo;
    public List<survey> listAll() {
        return repo.findAll();
    }

    public void save(Survey survey) {
        repo.save(survey);
    }

    public Survey get(String name) {
        return repo.findByName(name).get();
    }

    public void delete(String name) {
        repo.deleteByName(name);
    }
}
