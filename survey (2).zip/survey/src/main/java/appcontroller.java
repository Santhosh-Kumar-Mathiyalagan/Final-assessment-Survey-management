
package net.codejava;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {

    @Autowired
    private Survey service;

    @RequestMapping("/")
    public String viewHomePage(Model model) {
        List<service> listProducts = service.listAll();
        model.addAttribute("listSurvey", listSurvey);

        return "index";
    }

    @RequestMapping("/new")
    public String showNewSurveyPage(Model model) {
        Survey survey = new Survey();
        model.addAttribute("survey", survey);

        return "new_survey";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveSurvey(@ModelAttribute("survey") Survey survey) {
        service.save();

        return "redirect:/";
    }

    @RequestMapping("/edit/{id}")
    public ModelAndView showEditSurveyPage(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("edit_survey");
        Survey survey = service.get(id);
        mav.addObject("survey", survey);

        return mav;
    }

    @RequestMapping("/delete/{id}")
    public String deleteProduct(@PathVariable(name = "name") String name) {
        service.delete(name);
        return "redirect:/";
    }
}