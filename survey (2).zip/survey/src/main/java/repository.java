package net.codejava;
import org.springframework.data.jpa.repository.JpaRepository;
public interface repository extends JpaRepository<survey, Long> {
}